package com.wm.adapter.WmFlightAwareAdapter;



//-----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
//--- <<IS-START-IMPORTS>> ---
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import javax.net.ssl.*;
import com.google.gson.Gson;
//--- <<IS-END-IMPORTS>> ---

public final class Default

{
	// ---( internal utility methods )---

	final static Default _instance = new Default();

	static Default _newInstance() { return new Default(); }

	static Default _cast(Object o) { return (Default)o; }

	// ---( server methods )---




	public static final void Flightaware (IData pipeline)
     throws ServiceException
	{
		// --- <<IS-START(Flightaware)>> ---
		// @sigtype java 3.5
		// [o] recref:0:required FlightDoc Default:FlightDocument
		String machineName = "firehose.flightaware.com";
		SSLSocket ssl_socket;
		SSLParameters sslParams = new SSLParameters();
		sslParams.setEndpointIdentificationAlgorithm("HTTPS");
		sslParams.setProtocols(new String[] {"TLSv1.2"});
		String initiation_command = "live username sunaraya password 027bc6c9d470ec03ca3141ec356f158cd6613f2c";
		try
		{
		   ssl_socket = (SSLSocket) SSLSocketFactory.getDefault().createSocket(machineName, 1501);
		// enable certifcate validation:
		   ssl_socket.setSSLParameters(sslParams);
		   initiation_command += "\n";
		
		   //send your initiation command
		   OutputStreamWriter writer = new OutputStreamWriter(ssl_socket.getOutputStream(), "UTF8");
		   writer.write(initiation_command);
		   writer.flush();
		
		   InputStream inputStream = ssl_socket.getInputStream();
		   		
		   // read messages from FlightAware
		   BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
		   String message = null;
		   int limit = 10; //limit number messages for testing
		   Gson gson = new Gson();
		   //pipeline.
		   IData flightDoc = IDataFactory.create();  
		   //IDataCursor flightCursor = flightDoc.getCursor();  
		   //IDataUtil.put( inputCursor, "Flight", "input1" );	
		   while (limit > 0 && (message = reader.readLine()) != null) 
		   {
		       System.out.println("msg: " + message);
		       FlightObject flightObj = gson.fromJson(message, FlightObject.class);
		       //parse message with gson
		       System.out.printf("---------------- Parsing ---------------------\n");
		       limit--;
		       IData flight = IDataFactory.create();
		       IDataCursor cursor = flight.getCursor();  
		       IDataUtil.put(cursor, "type", flightObj.type);
		       IDataUtil.put(cursor, "ident", flightObj.ident);
		       IDataUtil.put(cursor, "air_ground", flightObj.air_ground);
		       IDataUtil.put(cursor, "alt", flightObj.alt);
		       IDataUtil.put(cursor, "clock", flightObj.clock);
		       IDataUtil.put(cursor, "id", flightObj.id);
		       IDataUtil.put(cursor, "gs", flightObj.gs);
		       IDataUtil.put(cursor, "heading", flightObj.heading);
		       IDataUtil.put(cursor, "lat", flightObj.lat);
		       IDataUtil.put(cursor, "lon", flightObj.lon);
		       IDataUtil.put(cursor, "reg", flightObj.reg);
		       IDataUtil.put(cursor, "squawk", flightObj.squawk);
		       IDataUtil.put(cursor, "updateType", flightObj.updateType);  
		       IDataUtil.append(flightDoc, flight);
		       cursor.destroy();
		   }
		   //IDataCursor master=pipeline.getCursor();
		   System.out.println("---****fligyt"+pipeline);
		   IDataUtil.append(pipeline, flightDoc);
		   writer.close();
		   reader.close();
		   inputStream.close();
		   ssl_socket.close();
		}
		catch (IOException e)
		{
			throw new ServiceException(e);
		}
		
			
		// --- <<IS-END>> ---

             
	}

	// --- <<IS-START-SHARED>> ---
	private class FlightObject {
	
	    //define here all fields of interest from the received messages
	    public String type;
	    public String ident;
	    public String air_ground;
	    public String alt;
	    public String clock;
	    public String id;
	    public String gs;
	    public String heading;
	    public String lat;
	    public String lon;
	    public String reg;
	    public String squawk;
	    public String updateType;
	
	    @Override
	    public String toString() {
	        String result;
	        //if any field is missing in the received message,
	        //for eg if "squawk" is missing then squawk value will be null!
	        //format as a table left justified, 10 chars min width
	        result = String.format("%-10s %-10s\n %-10s %-10s\n %-10s %-10s\n "
	                + "%-10s %-10s\n %-10s %-10s\n %-10s %-10s\n "
	                + "%-10s %-10s\n %-10s %-10s\n %-10s %-10s\n "
	                + "%-10s %-10s\n %-10s %-10s\n %-10s %-10s\n "
	                + "%-10s %-10s\n",
	                "type", type,
	                "ident", ident,
	                "airground", air_ground,
	                "alt", alt,
	                "clock", clock,
	                "id", id,
	                "gs", gs,
	                "heading", heading,
	                "lat", lat,
	                "lon", lon,
	                "reg", reg,
	                "squawk", squawk,
	                "updateType", updateType
	        );
	        return result;
	    }
	}
	// --- <<IS-END-SHARED>> ---
}


