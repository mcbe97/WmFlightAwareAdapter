package com.wm.adapter.WmFlightAwareAdapter;

import javax.resource.ResourceException;

import com.wm.adk.notification.WmAsyncListenerNotification;

public class AsyncListening extends WmAsyncListenerNotification implements WmFlightAwareConstants {

	@Override
	public boolean supports(Object arg0) throws ResourceException {
		// TODO Auto-generated method stub
		return false;
	}

}
